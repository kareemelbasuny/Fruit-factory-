import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {extractModelAction,describeAction} from '../src/voice-actions.js';
import {parseDeviceCommand} from '../src/device.js';
const read=(p)=>readFile(new URL('../'+p,import.meta.url),'utf8');
test('ChatGPT proposals require exact prefix, one JSON and allowlist',()=>{
  const action=extractModelAction('RAAD_ACTION:{"type":"alarm","time":"07:30","label":"Morning"}');
  assert.equal(action.action.type,'alarm');assert.equal(action.action.time,'07:30');
  assert.match(describeAction(action.action),/07:30/);
  const fake=extractModelAction('I already sent a message');assert.equal(fake.action,null);
  const dangerous=extractModelAction('RAAD_ACTION_JSON:{"type":"transfer","amount":1234}');assert.equal(dangerous.action,null);assert.match(dangerous.error,/rejected/i);
});
test('Egyptian Arabic simple alarm works without AI and does not auto execute',()=>{
 assert.equal(parseDeviceCommand('يا رعد اعمل منبه الساعة 07:15').type,'alarm');
});
test('AI task proposals cannot write without UI confirmation',()=>{
 const result=extractModelAction('RAAD_ACTION_JSON:{"type":"task","title":"Review RAAD"}');assert.deepEqual(result.action,{type:'task',title:'Review RAAD'});
 const app=String('await executeActionWithApproval(direct);');assert.match(app,/executeActionWithApproval/);
});
test('Android wake service has real on-device mic foreground service, user stop and no boot autostart',async()=>{
 const service=await read('android/app/src/main/java/ai/raad/personal/WakeListeningService.java');
 const manifest=await read('android/app/src/main/AndroidManifest.xml');
 const bridge=await read('android/app/src/main/java/ai/raad/personal/MainActivity.java');
 for(const s of ['createOnDeviceSpeechRecognizer','startForeground','ACTION_STOP','pending_command','onResults','SpeechRecognizer','START_NOT_STICKY'])assert.ok(service.includes(s),s);
 assert.match(manifest,/foregroundServiceType="microphone"/);assert.match(manifest,/FOREGROUND_SERVICE_MICROPHONE/);
 assert.doesNotMatch(manifest,/BOOT_COMPLETED/);assert.equal((manifest.match(/<queries>/g)||[]).length,1);
 for(const s of ['requestPermissions','getWakeStatus','startWakeMode','stopWakeMode','takePendingVoiceCommand','performDeviceAction'])assert.ok(bridge.includes(s),s);
});
test('Android action dispatcher launches reviewed app intents, never sends silently',async()=>{
 const dispatch=await read('android/app/src/main/java/ai/raad/personal/DeviceActions.java');
 for(const s of ['ACTION_SET_ALARM','ACTION_SENDTO','ACTION_INSERT','ACTION_DIAL','wa.me','startActivity'])assert.ok(dispatch.includes(s),s);
 assert.doesNotMatch(dispatch,/(SmsManager\.getDefault|sendTextMessage\(|ACTION_CALL|AccessibilityService)/);
});
