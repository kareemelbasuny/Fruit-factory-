import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {parseAgentAction,parseDeviceCommand,checkDeviceAction} from '../src/device.js';
const root=new URL('../',import.meta.url);
const read=rel=>readFile(new URL(rel,root),'utf8');

test('ChatGPT action envelope parses only whitelisted reviewed intents',()=>{
 assert.deepEqual(parseAgentAction('RAAD_ACTION:{"type":"alarm","time":"07:30","label":"Wake up"}'),{type:'alarm',time:'07:30',label:'Wake up'});
 assert.deepEqual(parseAgentAction('RAAD_ACTION:{"type":"task","title":"Review sales"}'),{type:'task',title:'Review sales'});
 assert.equal(parseAgentAction('RAAD_ACTION:{"type":"purchase","amount":99}'),null);
 assert.equal(parseAgentAction('hello'),null);
 assert.equal(parseAgentAction('RAAD_ACTION: {oops'),null);
});
test('Invalid phone, email, alarm, and malformed model payloads cannot execute',()=>{
 assert.throws(()=>checkDeviceAction('alarm',{time:'26:00'}));
 assert.throws(()=>parseAgentAction('RAAD_ACTION:{"type":"sms","phone":"123","message":"hi"}'));
 assert.throws(()=>parseAgentAction('RAAD_ACTION:{"type":"email","to":"not-an-email","body":"hi"}'));
 assert.throws(()=>parseAgentAction('RAAD_ACTION:{"type":"task","title":""}'));
});
test('Egyptian Arabic alarms can be parsed without an AI provider',()=>{
 assert.deepEqual(parseDeviceCommand('يا رعد اظبط منبه الساعة ٠٧:٣٠'),{type:'alarm',time:'07:30',label:'RAAD alarm'});
});
test('Android reviews actions in AlertDialog and sends through implicit user-facing intents',async()=>{
 const text=await read('android/app/src/main/java/ai/raad/personal/DeviceActionHandler.java');
 assert.match(text,/new AlertDialog\.Builder/);
 assert.match(text,/ACTION_SET_ALARM/);
 assert.match(text,/ACTION_SENDTO/);
 assert.match(text,/ACTION_DIAL/);
 assert.doesNotMatch(text,/SmsManager|sendTextMessage|ACTION_CALL/);
});
test('Wake microphone has explicit start, stop, time limit and visible notification',async()=>{
 const service=await read('android/app/src/main/java/ai/raad/personal/WakeListeningService.java');
 const manifest=await read('android/app/src/main/AndroidManifest.xml');
 assert.match(service,/MAX_MS=5 \* 60 \* 1000/);
 assert.match(service,/\.setOngoing\(true\)/);
 assert.match(service,/ACTION_STOP/);
 assert.match(service,/START_NOT_STICKY/);
 assert.match(manifest,/FOREGROUND_SERVICE_MICROPHONE/);
 assert.match(manifest,/android:exported="false"/);
 assert.doesNotMatch(manifest,/RECEIVE_BOOT_COMPLETED/);
});
