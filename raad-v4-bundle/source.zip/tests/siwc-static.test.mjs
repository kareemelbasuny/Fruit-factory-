import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
const read = async f => readFile(new URL('../'+f,import.meta.url),'utf8');
test('native login uses official OAuth PKCE and limits scopes',async()=>{
 const code=await read('android/app/src/main/java/ai/raad/personal/ChatGPTConnector.java');
 for(const item of ['https://auth.openai.com/api/accounts/authorize','code_challenge_method','S256','127.0.0.1','auth/callback','chatgpt.tokens.use.direct','verifyId','Signature.getInstance("SHA256withRSA")'])assert.ok(code.includes(item),item);
 assert.match(code,/AndroidKeyStore/);assert.match(code,/AES\/GCM\/NoPadding/);
 assert.match(code,/MessageDigest.isEqual/);
 assert.ok(!code.includes('sk-proj-'));
});
test('official Responses API must be non-storing and streamed',async()=>{
 const code=await read('android/app/src/main/java/ai/raad/personal/ChatGPTConnector.java');
 assert.match(code,/"store",false/);assert.match(code,/"stream",true/);
 assert.match(code,/"response.completed"/);assert.match(code,/refresh_token/);
});
test('only native bridge receives tokens, web gets status and text',async()=>{
 const activity=await read('android/app/src/main/java/ai/raad/personal/MainActivity.java');
 assert.match(activity,/connectChatGPT/);assert.match(activity,/getChatGPTStatus/);
 assert.match(activity,/askChatGPT/);assert.match(activity,/openChatGPTWithPrompt/);
 const app=await read('src/app.js');
 assert.match(app,/state.chatGPT.connected/);assert.match(app,/nativeChatGPTReply/);
 assert.match(app,/Continue in ChatGPT app/);
 assert.match(app,/Connecting your ChatGPT account/);
});

test('OAuth return opens the existing Android activity rather than a new stale WebView',async()=>{
 const xml=await read('android/app/src/main/AndroidManifest.xml');
 assert.match(xml,/android:launchMode="singleTask"/);
 assert.match(xml,/android:scheme="raad"/);
});
