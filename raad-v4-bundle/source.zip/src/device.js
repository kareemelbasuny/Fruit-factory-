/** Device actions are deterministic requests. They never access accounts or send automatically. */
export function normalizeDigits(value='') {
  return String(value).replace(/[٠-٩۰-۹]/g, c => String('٠١٢٣٤٥٦٧٨٩'.indexOf(c) >= 0 ? '٠١٢٣٤٥٦٧٨٩'.indexOf(c) : '۰۱۲۳۴۵۶۷۸۹'.indexOf(c)));
}
export function checkDeviceAction(type, args={}) {
  const text=v=>String(v||'').trim();
  if(type==='alarm') {
    const time=normalizeDigits(text(args.time));
    const matched=/^([01]?\d|2[0-3]):([0-5]\d)$/.exec(time);
    if(!matched) throw Error('Enter alarm time as HH:MM (24-hour).');
    return {type,time:`${matched[1].padStart(2,'0')}:${matched[2]}`,label:text(args.label).slice(0,80)||'RAAD alarm'};
  }
  if(['sms','whatsapp','dial'].includes(type)) {
    const phone=normalizeDigits(text(args.phone)).replace(/[ ()-]/g,'');
    if(!/^\+?[0-9]{7,15}$/.test(phone)) throw Error('Enter a valid phone number (7–15 digits, optional +).');
    if(type==='dial') return {type,phone};
    const message=text(args.message);
    if(!message || message.length>1800) throw Error('Message must contain 1–1800 characters.');
    return {type,phone,message};
  }
  if(type==='email') {
    const to=text(args.to);
    if(to.length>254||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(to))throw Error('Enter one valid recipient email address.');
    const subject=text(args.subject), body=text(args.body);
    if(subject.length>200||body.length>6000)throw Error('Email subject/body too long.');
    if(!body)throw Error('Write an email message.');
    return {type,to,subject,body};
  }
  if(type==='calendar'){
    const title=text(args.title);const start=text(args.start);
    if(!title||title.length>100)throw Error('Enter an event title (up to 100 characters).');
    if(!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(start)||!Number.isFinite(Date.parse(start)))throw Error('Enter an event start date and time.');
    const parsed=new Date(start);
    if(Number.isNaN(parsed.getTime()))throw Error('Invalid calendar date.');
    return {type,title,start,details:text(args.details).slice(0,1500)};
  }
  if(type==='contacts'||type==='settings'||type==='notification-test')return {type};
  throw Error('Unsupported device action.');
}
export function parseDeviceCommand(input) {
  const text=normalizeDigits(String(input||'').trim());
  const alarm=text.match(/^(?:يا رعد[،, ]*)?(?:(?:اعمل|اضبط|اظبط|حط|ظبط|شغّل|شغل)\s*)?(?:منبه|منبّه|alarm|set alarm)(?:\s*(?:الساعة|at|for))?\s*([01]?\d|2[0-3]):([0-5]\d)(.*)$/i);
  if(alarm){return checkDeviceAction('alarm',{time:`${alarm[1]}:${alarm[2]}`,label:alarm[3].trim()||'RAAD alarm'});}
  const sms=text.match(/^(?:sms|send sms|رسالة نصية|ابعت sms)\s+(?:to\s+|إلى\s+|ل\s*)?(\+?\d[\d\s()-]{6,20})\s*[:：]\s*(.+)$/is);
  if(sms)return checkDeviceAction('sms',{phone:sms[1],message:sms[2]});
  const wa=text.match(/^(?:whatsapp|واتساب|ابعت واتساب)\s+(?:to\s+|إلى\s+|ل\s*)?(\+?\d[\d\s()-]{6,20})\s*[:：]\s*(.+)$/is);
  if(wa)return checkDeviceAction('whatsapp',{phone:wa[1],message:wa[2]});
  return null;
}
export const DEVICE_COPY={
 alarm:'Your Clock app will open to review this alarm.',
 sms:'Your SMS app will open with a draft. You must press Send.',
 whatsapp:'WhatsApp will open with a prepared message. You must press Send.',
 email:'Your email app will open with a draft. You must press Send.',
 calendar:'Your calendar will open to review and save the event.',
 contacts:'The Android contact picker will open. Only the contact you choose is shared.',
 dial:'Your phone dialer will open. The call will not start automatically.',
 settings:'Android will open RAAD app settings for you to manage permissions.',
 'notification-test':'A test notification will be shown only if permission is granted.'
};

/** Explicit agent-action envelope. Model responses are data, never executable code. */
export function parseAgentAction(answer) {
  const text=String(answer||'').trim();
  const match=/^RAAD_ACTION:\s*(\{[^]*\})$/.exec(text);
  if(!match||match[1].length>9000)return null;
  let parsed;
  try{parsed=JSON.parse(match[1]);}catch{return null;}
  if(!parsed||typeof parsed!=='object'||Array.isArray(parsed))return null;
  const type=parsed.type;
  if(!['alarm','sms','whatsapp','email','dial','calendar','task'].includes(type))return null;
  if(type==='task') {
    const title=String(parsed.title||'').trim();
    if(!title||title.length>120)throw Error('Task title must be 1–120 characters.');
    return {type,title};
  }
  return checkDeviceAction(type,parsed);
}
