package ai.raad.personal;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Locale;

/**
 * Explicit, time-bounded, best-effort voice wake session.
 * Android SpeechRecognizer is NOT an always-on hotword engine. The OS/recognition
 * provider may stop microphone capture (especially with the display off).
 * User starts this microphone foreground service while app is visible.
 * The service never boots itself, bypasses keyguard, or sends messages.
 */
public final class WakeListeningService extends Service implements RecognitionListener {
  public static final String ACTION_START="ai.raad.personal.WAKE_START";
  public static final String ACTION_STOP="ai.raad.personal.WAKE_STOP";
  private static final int NOTIFICATION_ID=912;
  private static final String CHANNEL="raad_microphone_short";
  private static final long MAX_MS=5 * 60 * 1000;
  private final Handler main=new Handler(Looper.getMainLooper());
  private SpeechRecognizer recognizer;
  private boolean active=false, listening=false, expectCommand=false;
  private int failures=0;
  private long expiresAt=0;
  private String language="ar-EG";
  private final Runnable timeout=()->stopSelf();
  private final Runnable restart=()->startRecognition();

  @Override public int onStartCommand(Intent intent, int flags, int startId){
    if(intent!=null && ACTION_STOP.equals(intent.getAction())){stopSelf();return START_NOT_STICKY;}
    if(!ACTION_START.equals(intent==null?null:intent.getAction()))return START_NOT_STICKY;
    if(active)return START_NOT_STICKY;
    if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){stopSelf();return START_NOT_STICKY;}
    language="en".equals(intent.getStringExtra("language"))?"en-US":"ar-EG";
    NotificationManager manager=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
    if(Build.VERSION.SDK_INT>=26)manager.createNotificationChannel(new NotificationChannel(CHANNEL,"RAAD temporary voice listening",NotificationManager.IMPORTANCE_LOW));
    try {
      if(Build.VERSION.SDK_INT>=29)startForeground(NOTIFICATION_ID,notification("Listening for 'Ya Raad' · 5 minutes"),ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
      else startForeground(NOTIFICATION_ID,notification("Listening for 'Ya Raad' · 5 minutes"));
    }catch(Exception e){stopSelf();return START_NOT_STICKY;}
    if(!SpeechRecognizer.isRecognitionAvailable(this)){
      Toast.makeText(this,"Android voice recognition is unavailable",Toast.LENGTH_LONG).show();stopSelf();return START_NOT_STICKY;
    }
    active=true;expiresAt=System.currentTimeMillis()+MAX_MS;failures=0;
    try {recognizer=SpeechRecognizer.createSpeechRecognizer(this);recognizer.setRecognitionListener(this);}
    catch(Exception e){stopSelf();return START_NOT_STICKY;}
    main.postDelayed(timeout,MAX_MS);startRecognition();
    return START_NOT_STICKY;
  }
  private Notification notification(String label){
    Intent open=new Intent(this,MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
    PendingIntent show=PendingIntent.getActivity(this,102,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    Intent stop=new Intent(this,WakeListeningService.class).setAction(ACTION_STOP);
    PendingIntent cancel=PendingIntent.getService(this,103,stop,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    return new Notification.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.ic_btn_speak_now)
      .setContentTitle("RAAD · temporary voice access").setContentText(label)
      .setContentIntent(show).setOngoing(true).setShowWhen(false)
      .addAction(android.R.drawable.ic_menu_close_clear_cancel,"Stop",cancel).build();
  }
  private void updateNotice(String text){
    NotificationManager m=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
    if(m!=null)m.notify(NOTIFICATION_ID,notification(text));
  }
  private void startRecognition(){
    if(!active||recognizer==null||System.currentTimeMillis()>=expiresAt){stopSelf();return;}
    if(listening)return;
    Intent request=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
    request.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
    request.putExtra(RecognizerIntent.EXTRA_LANGUAGE,language);
    request.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,1);
    request.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,false);
    try{listening=true;recognizer.startListening(request);}catch(Exception e){listening=false;if(++failures>=4)stopSelf();else main.postDelayed(restart,1200);}
  }
  private void queueNext(){
    listening=false;
    if(active && System.currentTimeMillis()<expiresAt){main.removeCallbacks(restart);main.postDelayed(restart,1300);}
  }
  private static String commandAfterWake(String phrase){
    String p=phrase.trim().replace('،',' ').replace(',',' ');
    String lower=p.toLowerCase(Locale.ROOT);
    for(String key:new String[]{"يا رعد","يا راد","hey raad","ok raad","raad","رعد"}){
      int position=lower.indexOf(key);
      if(position>=0){return p.substring(position+key.length()).trim();}
    }
    return null;
  }
  @Override public void onResults(Bundle data){
    listening=false;
    ArrayList<String> texts=data.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
    String phrase=texts!=null && !texts.isEmpty()?texts.get(0):"";
    if(!phrase.isEmpty()){
      String command=commandAfterWake(phrase);
      if(command!=null){
        failures=0;
        if(command.isEmpty()){
          expectCommand=true;
          updateNotice("RAAD heard you. Say your command now.");
        } else {
          expectCommand=false;
          MainActivity.recordWakeCommand(this,command);
          updateNotice("Voice command ready · tap to review");
        }
      } else if(expectCommand){
        expectCommand=false;
        MainActivity.recordWakeCommand(this,phrase.trim());
        updateNotice("Voice command ready · tap to review");
      }
    }
    queueNext();
  }
  @Override public void onError(int error){
    listening=false;
    if(error==SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS || error==SpeechRecognizer.ERROR_RECOGNIZER_BUSY || error==SpeechRecognizer.ERROR_SERVER || error==SpeechRecognizer.ERROR_CLIENT){
      if(++failures>=4){stopSelf();return;}
    } else if(error!=SpeechRecognizer.ERROR_NO_MATCH && error!=SpeechRecognizer.ERROR_SPEECH_TIMEOUT) failures++;
    queueNext();
  }
  @Override public void onReadyForSpeech(Bundle params){}
  @Override public void onBeginningOfSpeech(){}
  @Override public void onRmsChanged(float rmsdB){}
  @Override public void onBufferReceived(byte[] buffer){}
  @Override public void onEndOfSpeech(){}
  @Override public void onPartialResults(Bundle results){}
  @Override public void onEvent(int eventType,Bundle params){}
  @Override public void onDestroy(){
    active=false;main.removeCallbacks(restart);main.removeCallbacks(timeout);
    if(recognizer!=null){try{recognizer.cancel();recognizer.destroy();}catch(Exception ignored){}recognizer=null;}
    super.onDestroy();
  }
  @Override public IBinder onBind(Intent intent){return null;}
}
