package ai.raad.personal;

import android.app.Activity;
import android.app.AlarmManager;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.provider.AlarmClock;
import android.provider.CalendarContract;
import android.provider.ContactsContract;
import org.json.JSONObject;
import java.util.regex.Pattern;

/** Strict allowlist: external apps display and confirm the final action. Never sends messages. */
public final class DeviceActions {
    private DeviceActions() { }
    private static final Pattern PHONE=Pattern.compile("\\+?[0-9]{7,15}");
    private static final Pattern EMAIL=Pattern.compile("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$");
    public static void open(Activity activity, String json) throws Exception {
        if(json==null||json.length()>9000)throw new IllegalArgumentException("Action too large");
        JSONObject a=new JSONObject(json); String type=a.optString("type");
        Intent intent;
        switch(type) {
            case "alarm": {
                String time=a.optString("time");
                if(!time.matches("(?:[01][0-9]|2[0-3]):[0-5][0-9]"))throw new IllegalArgumentException("Invalid alarm time");
                String[] p=time.split(":");
                intent=new Intent(AlarmClock.ACTION_SET_ALARM);
                intent.putExtra(AlarmClock.EXTRA_HOUR,Integer.parseInt(p[0]));
                intent.putExtra(AlarmClock.EXTRA_MINUTES,Integer.parseInt(p[1]));
                intent.putExtra(AlarmClock.EXTRA_MESSAGE,limit(a.optString("label","RAAD alarm"),80));
                intent.putExtra(AlarmClock.EXTRA_SKIP_UI,false);
                break;
            }
            case "sms": {
                String phone=checkPhone(a);String message=limitRequired(a.optString("message"),1800);
                intent=new Intent(Intent.ACTION_SENDTO,Uri.parse("smsto:"+phone));
                intent.putExtra("sms_body",message);break;
            }
            case "whatsapp": {
                String phone=checkPhone(a).replace("+","");String msg=limitRequired(a.optString("message"),1800);
                intent=new Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/"+phone+"?text="+Uri.encode(msg)));break;
            }
            case "email": {
                String address=a.optString("to");if(address.length()>254||!EMAIL.matcher(address).matches())throw new IllegalArgumentException("Invalid email address");
                intent=new Intent(Intent.ACTION_SENDTO,Uri.parse("mailto:"+Uri.encode(address)));
                intent.putExtra(Intent.EXTRA_EMAIL,new String[]{address});
                intent.putExtra(Intent.EXTRA_SUBJECT,limit(a.optString("subject"),200));
                intent.putExtra(Intent.EXTRA_TEXT,limitRequired(a.optString("body"),6000));break;
            }
            case "calendar": {
                String name=limitRequired(a.optString("title"),100);
                String start=a.optString("start");
                if(!start.matches("\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}"))throw new IllegalArgumentException("Invalid event date/time");
                java.text.SimpleDateFormat fmt=new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm",java.util.Locale.US);
                fmt.setLenient(false); long millis=fmt.parse(start).getTime();
                intent=new Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI);
                intent.putExtra(CalendarContract.Events.TITLE,name);
                intent.putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME,millis);
                intent.putExtra(CalendarContract.EXTRA_EVENT_END_TIME,millis+3600000L);
                intent.putExtra(CalendarContract.Events.DESCRIPTION,limit(a.optString("details"),1500));break;
            }
            case "dial":intent=new Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+checkPhone(a)));break;
            case "contacts":intent=new Intent(Intent.ACTION_PICK,ContactsContract.Contacts.CONTENT_URI);break;
            case "settings":intent=new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+activity.getPackageName()));break;
            default:throw new IllegalArgumentException("Unsupported action");
        }
        if(intent.resolveActivity(activity.getPackageManager())==null)throw new ActivityNotFoundException("No compatible app available for "+type);
        activity.startActivity(intent);
    }
    private static String checkPhone(JSONObject a){String p=a.optString("phone").replaceAll("[ ()-]","");if(!PHONE.matcher(p).matches())throw new IllegalArgumentException("Invalid phone number");return p;}
    private static String limit(String s,int max){return s==null?"":s.substring(0,Math.min(s.length(),max));}
    private static String limitRequired(String s,int max){if(s==null||s.trim().isEmpty()||s.length()>max)throw new IllegalArgumentException("Invalid content");return s;}
}
