import {createServer} from 'node:http';
import {readFile} from 'node:fs/promises';
import {join,extname,normalize} from 'node:path';
const root=new URL('../',import.meta.url).pathname;
const mime={'.html':'text/html','.js':'text/javascript','.css':'text/css','.json':'application/json','.webmanifest':'application/manifest+json','.svg':'image/svg+xml','.png':'image/png'};
const server=createServer(async(req,res)=>{try{const path=decodeURIComponent(new URL(req.url,'http://localhost').pathname);const file=join(root,path==='/'?'index.html':path);if(!file.startsWith(root))throw Error('Path denied');const data=await readFile(file);res.writeHead(200,{'Content-Type':mime[extname(file)]||'application/octet-stream','Cache-Control':'no-cache'});res.end(data);}catch{res.writeHead(404);res.end('Not Found');}});
server.listen(Number(process.env.PORT||4173),'0.0.0.0',()=>console.log('RAAD preview on port '+(process.env.PORT||4173)));
