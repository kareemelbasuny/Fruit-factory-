import {rm,mkdir,cp,copyFile,stat} from 'node:fs/promises';
import {join} from 'node:path';
const root=new URL('../',import.meta.url).pathname;
const out=join(root,'dist');
await rm(out,{recursive:true,force:true});await mkdir(out,{recursive:true});
for(const file of ['index.html','manifest.webmanifest','sw.js','_headers'])await copyFile(join(root,file),join(out,file));
for(const dir of ['src','icons'])await cp(join(root,dir),join(out,dir),{recursive:true});
for(const file of ['index.html','src/app.js','src/styles.css','icons/icon-192.png']){const data=await stat(join(out,file));if(!data.size)throw Error(`Empty output file ${file}`);}
console.log(`RAAD static build ready at ${out}. No dependencies or paid APIs required.`);
