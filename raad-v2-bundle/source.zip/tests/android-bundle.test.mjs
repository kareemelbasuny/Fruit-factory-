import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile,stat} from 'node:fs/promises';
const project = new URL('../',import.meta.url);
const read = (rel)=>readFile(new URL(rel,project),'utf8');
test('Android wrapper keeps network and credentials optional', async()=>{
 const manifest=await read('android/app/src/main/AndroidManifest.xml');
 assert.match(manifest,/android:usesCleartextTraffic="false"/);
 assert.match(manifest,/android:allowBackup="false"/);
 assert.match(manifest,/android:exported="true"/);
 const activity=await read('android/app/src/main/java/ai/raad/personal/MainActivity.java');
 assert.match(activity,/new WebView\(this\)/);
 assert.match(activity,/setDomStorageEnabled\(true\)/);
 assert.match(activity,/setAllowFileAccess\(false\)/);
 assert.match(activity,/WebResourceResponse shouldInterceptRequest/);
 assert.match(activity,/https:\/\//);
 assert.ok(activity.includes('path.matches("/[a-zA-Z0-9_./-]+")'));
});
test('Android backup and native voice bridge have explicit user actions',async()=>{
 const activity=await read('android/app/src/main/java/ai/raad/personal/MainActivity.java');
 assert.match(activity,/ACTION_CREATE_DOCUMENT/);
 assert.match(activity,/ACTION_OPEN_DOCUMENT/);
 assert.match(activity,/ACTION_RECOGNIZE_SPEECH/);
 assert.match(activity,/TextToSpeech/);
 const app=await read('src/app.js');
 assert.match(app,/RaadAndroid\.exportBackup/);
 assert.match(app,/RaadAndroid\.listen/);
 assert.match(app,/raad-native-export/);
});
test('Android build workflow produces an installable debug APK artifact',async()=>{
 const workflow=await read('.github/workflows/android-apk.yml');
 assert.match(workflow,/assembleDebug/);
 assert.match(workflow,/upload-artifact@v4/);
 const packaging=await read('tools/package-android.mjs');
 assert.match(packaging,/dist/);
 assert.ok((await stat(new URL('icons/icon-192.png',project))).size>0);
});
