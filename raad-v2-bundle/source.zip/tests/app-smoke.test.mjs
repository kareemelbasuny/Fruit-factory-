import test from 'node:test';
import assert from 'node:assert/strict';

// Dependency-free, in-memory substitute for IndexedDB/DOM to smoke-test actual app UI code.
// Does NOT replace real Android/Chrome end-to-end verification.
const stores=new Map();
const objectStoreNames={contains:k=>stores.has(k)};
const db={objectStoreNames,createObjectStore:k=>{stores.set(k,new Map());},transaction:(names)=>{const tx={oncomplete:null,onerror:null,objectStore(name){return {getAll(){const req={onsuccess:null,onerror:null,result:[]};queueMicrotask(()=>{req.result=[...stores.get(name).values()];req.onsuccess?.()});return req;},put(item){stores.get(name).set(item.id,item);queueMicrotask(()=>tx.oncomplete?.());},delete(id){stores.get(name).delete(id);queueMicrotask(()=>tx.oncomplete?.());},clear(){stores.get(name).clear();queueMicrotask(()=>tx.oncomplete?.());}}}};return tx;}};
globalThis.indexedDB={open(){const req={result:db,onsuccess:null,onerror:null,onupgradeneeded:null};queueMicrotask(()=>{req.onupgradeneeded?.();req.onsuccess?.()});return req;}};
const handlers={};const root={innerHTML:'',addEventListener:(k,h)=>handlers[k]=h};
globalThis.document={getElementById:(id)=>id==='app'?root:null,querySelector:()=>null,visibilityState:'visible'};
Object.defineProperty(globalThis,'navigator',{value:{onLine:true},configurable:true});
globalThis.window={addEventListener(){},scrollTo(){}};
globalThis.location={protocol:'file:'};
const realSetInterval=globalThis.setInterval;globalThis.setInterval=()=>0;
class FakeHTMLFormElement{constructor(fields){this.id='record-form';this.dataset={kind:'tasks',id:''};this.fields=fields;}querySelector(){return {disabled:false,isConnected:false}}}
class FakeFormData{constructor(form){this.fields=form.fields;}*[Symbol.iterator](){yield* Object.entries(this.fields);}}
globalThis.HTMLFormElement=FakeHTMLFormElement;globalThis.FormData=FakeFormData;
await import('../src/app.js');
for(let i=0;i<20&&!handlers.click;i++)await new Promise(r=>setTimeout(r,1));
await new Promise(r=>setTimeout(r,10));

test('application renders real overview and all main navigation',()=>{
 assert.match(root.innerHTML,/MISSION CONTROL/);assert.match(root.innerHTML,/RAAD Assistant/);
 assert.match(root.innerHTML,/Income Opportunities/);assert.match(root.innerHTML,/Investments/);
});
test('create a task via actual modal+submit handlers and show on Tasks page',async()=>{
 await handlers.click({target:{closest(sel){if(sel==='[data-page]')return null;if(sel==='[data-action]')return {dataset:{action:'new',kind:'tasks'}};return null;}}});
 assert.match(root.innerHTML,/Create Task/);
 const form=new FakeHTMLFormElement({title:'Smoke test task',status:'To Do',priority:'High',due:'2026-11-14'});
 await handlers.submit({target:form,preventDefault(){}});
 assert.equal(stores.get('tasks').size,1);
 await handlers.click({target:{closest(sel){if(sel==='[data-page]')return {dataset:{page:'tasks'}};return null;}}});
 assert.match(root.innerHTML,/Smoke test task/);
 assert.match(root.innerHTML,/TASKS/i);
});
test('task data persists in the database behind the current UI',()=>{
 assert.equal([...stores.get('tasks').values()][0].title,'Smoke test task');
 assert.equal([...stores.get('tasks').values()][0].status,'To Do');
});
globalThis.setInterval=realSetInterval;
