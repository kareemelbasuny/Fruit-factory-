import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile,stat} from 'node:fs/promises';
import {today,validateRecord,investmentSummary,nextRunFor,dueAutomations,escapeHTML,chatDirection} from '../src/utils.js';
import {localReply} from '../src/ai.js';

test('local task command requests confirmation instead of pretending to take action',()=>{
 const result=localReply('create task: Plan SaaS launch','en',{tasks:[],projects:[]});
 assert.equal(result.mode,'confirm');assert.equal(result.action.kind,'tasks');assert.equal(result.action.title,'Plan SaaS launch');
});
test('local assistant clearly says live AI is unavailable',()=>{
 const result=localReply('Research 2026 market competition','ar-EG',{tasks:[],projects:[]});
 assert.equal(result.mode,'local');assert.match(result.text,/مفيش موديل AI/);
});
test('assistant daily summary uses actual task data',()=>{
 const result=localReply('يا رعد، عندي ايه النهارده؟','ar-EG',{tasks:[{title:'Meeting preparation',due:today(),status:'To Do'}],events:[],projects:[]});
 assert.match(result.text,/1 مهام/);assert.match(result.text,/Meeting preparation/);
});
test('record validation protects required fields and invalid numbers',()=>{
 assert.ok(validateRecord('tasks',{title:''}).length>0);
 assert.ok(validateRecord('business',{title:'Expense',amount:-10}).length>0);
 assert.deepEqual(validateRecord('tasks',{title:'Plan week',due:'2026-11-20'}),[]);
 assert.ok(validateRecord('events',{title:'Meet',startsAt:'2026-11-20T10:00',endsAt:'2026-11-20T09:00'}).length>0);
});
test('portfolio never assumes a missing market price is zero',()=>{
 const s=investmentSummary([{symbol:'EGAL',quantity:4,avgCost:30,currentPrice:'',currency:'EGP'},{symbol:'JUFO',quantity:2,avgCost:10,currentPrice:13,currency:'EGP'}]);
 assert.equal(s.EGP.cost,140);assert.equal(s.EGP.value,26);assert.equal(s.EGP.gain,6);assert.equal(s.EGP.priced,1);assert.equal(s.EGP.unpriced,1);
});
test('no currency conversion is invented',()=>{
 const s=investmentSummary([{quantity:2,avgCost:11,currentPrice:12,currency:'USD'},{quantity:5,avgCost:50,currentPrice:55,currency:'EGP'}]);
 assert.equal(s.USD.cost,22);assert.equal(s.EGP.cost,250);assert.equal(Object.keys(s).length,2);
});
test('only active and due automations are selected',()=>{
 const now=new Date('2026-11-13T10:00:00Z');
 const tasks=[{status:'Active',nextRun:'2026-11-13T09:00:00Z'},{status:'Paused',nextRun:'2026-11-13T09:00:00Z'},{status:'Active',nextRun:'2026-11-14T09:00:00Z'}];
 assert.equal(dueAutomations(tasks,now).length,1);
 assert.equal(new Date(nextRunFor('Weekly',now)).getTime()-now.getTime(),7*86400_000);
});
test('untrusted user text is escaped for HTML and RTL is detected',()=>{
 assert.equal(escapeHTML('<script>alert("x")</script>'),'&lt;script&gt;alert(&quot;x&quot;)&lt;/script&gt;');
 assert.equal(chatDirection('يا رعد'),'rtl');assert.equal(chatDirection('Hello RAAD'),'ltr');
});
test('PWA and application entry files are included',async()=>{
 const files=['index.html','src/app.js','src/styles.css','sw.js','manifest.webmanifest','icons/icon-192.png','icons/icon-512.png'];
 for(const file of files){const s=await stat(new URL('../'+file,import.meta.url));assert.ok(s.size>100,file);}
 const manifest=JSON.parse(await readFile(new URL('../manifest.webmanifest',import.meta.url),'utf8'));
 assert.equal(manifest.display,'standalone');assert.equal(manifest.short_name,'RAAD');
});
