-- Run this SQL only in your own Supabase project, in the SQL Editor.
-- Auth users are managed by Supabase Auth. Each user can access their own snapshot.
create table if not exists public.user_snapshots (
  user_id uuid primary key references auth.users(id) on delete cascade,
  data jsonb not null,
  updated_at timestamptz not null default now()
);
alter table public.user_snapshots enable row level security;
revoke all on public.user_snapshots from anon;
grant select,insert,update,delete on public.user_snapshots to authenticated;
drop policy if exists "owner_select" on public.user_snapshots;
drop policy if exists "owner_insert" on public.user_snapshots;
drop policy if exists "owner_update" on public.user_snapshots;
drop policy if exists "owner_delete" on public.user_snapshots;
create policy "owner_select" on public.user_snapshots for select to authenticated using (auth.uid()=user_id);
create policy "owner_insert" on public.user_snapshots for insert to authenticated with check (auth.uid()=user_id);
create policy "owner_update" on public.user_snapshots for update to authenticated using (auth.uid()=user_id) with check (auth.uid()=user_id);
create policy "owner_delete" on public.user_snapshots for delete to authenticated using (auth.uid()=user_id);
