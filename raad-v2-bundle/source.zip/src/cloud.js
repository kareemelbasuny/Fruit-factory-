import {snapshot,replaceSnapshot} from './db.js';
// Supabase anon key is public by design; RLS confines data to authenticated user ID.
let session=null;let config=null;
function base(url){try{const u=new URL(url);if(u.protocol!=='https:')throw Error();return u.origin;}catch{throw Error('Cloud URL must be HTTPS.');}}
async function request(path,{method='GET',body}={}){if(!config)throw Error('Cloud not configured.');const headers={'apikey':config.anonKey,'Content-Type':'application/json'};if(session?.access_token)headers.Authorization=`Bearer ${session.access_token}`;const response=await fetch(`${base(config.url)}${path}`,{method,headers,body:body===undefined?undefined:JSON.stringify(body)});const text=await response.text();const parsed=text?JSON.parse(text):null;if(!response.ok)throw Error(parsed?.msg||parsed?.error_description||parsed?.message||`Cloud error: ${response.status}`);return parsed;}
export function configureCloud(c){config=c?.url&&c?.anonKey?{url:c.url,anonKey:c.anonKey}:null;session=null;}
export async function signIn(email,password){if(!email||!password)throw Error('Email and password required.');session=await request('/auth/v1/token?grant_type=password',{method:'POST',body:{email,password}});return session.user?.email||email;}
export async function signOut(){session=null;}
export function cloudConnected(){return Boolean(session?.access_token);}
export function cloudAccessToken(){return session?.access_token||null;}
export async function uploadSnapshot(){if(!cloudConnected())throw Error('Sign in before syncing.');const body=await snapshot();await request('/rest/v1/user_snapshots?on_conflict=user_id',{method:'POST',body:{user_id:session.user.id,data:body,updated_at:new Date().toISOString()}}); // POST upsert needs Prefer; use PATCH-or-POST below if needed
 return body.exportedAt;}
export async function cloudUpsert(){if(!cloudConnected())throw Error('Sign in before syncing.');const body=await snapshot();const res=await fetch(`${base(config.url)}/rest/v1/user_snapshots?on_conflict=user_id`,{method:'POST',headers:{apikey:config.anonKey,Authorization:`Bearer ${session.access_token}`,'Content-Type':'application/json',Prefer:'resolution=merge-duplicates,return=minimal'},body:JSON.stringify({user_id:session.user.id,data:body,updated_at:new Date().toISOString()})});if(!res.ok)throw Error(`Cloud sync error (${res.status}): ${(await res.text()).slice(0,240)}`);return body.exportedAt;}
export async function cloudDownload(){if(!cloudConnected())throw Error('Sign in before syncing.');const result=await request(`/rest/v1/user_snapshots?user_id=eq.${encodeURIComponent(session.user.id)}&select=data,updated_at`);if(!result?.length)throw Error('No cloud backup exists.');await replaceSnapshot(result[0].data);return result[0].updated_at;}
