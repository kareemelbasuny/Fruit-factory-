export const uid = () => (globalThis.crypto?.randomUUID?.() || `${Date.now()}-${Math.random().toString(36).slice(2)}`);
let calendarTimezone='Africa/Cairo';
export function setCalendarTimezone(value){try{new Intl.DateTimeFormat('en-US',{timeZone:value});calendarTimezone=value;}catch{calendarTimezone='Africa/Cairo';}}
export const today = () => {const parts=Object.fromEntries(new Intl.DateTimeFormat('en-US',{timeZone:calendarTimezone,year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date()).map(p=>[p.type,p.value]));return `${parts.year}-${parts.month}-${parts.day}`;};
export function localISO(date){const d=new Date(date);return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;}
export const escapeHTML = (value='') => String(value ?? '').replace(/[&<>"']/g, ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
export function money(value,currency='EGP'){return new Intl.NumberFormat('en-EG',{style:'currency',currency,maximumFractionDigits:2}).format(Number(value)||0);}
export function dateLabel(d){if(!d)return 'No date'; const date=new Date(`${d}T12:00:00`);return Number.isNaN(date.getTime())?'Invalid date':date.toLocaleDateString('en-EG',{day:'numeric',month:'short',year:'numeric'});}
export function dateTimeLabel(d){if(!d)return 'Not scheduled';const date=new Date(d);return Number.isNaN(date.getTime())?'Invalid date':date.toLocaleString('en-EG',{day:'numeric',month:'short',hour:'numeric',minute:'2-digit',timeZone:calendarTimezone});}
export const clamp=(n,min,max)=>Math.min(max,Math.max(min,n));
export const sum=(items,key)=>items.reduce((s,item)=>s+(Number(item[key])||0),0);
export const safeURL=(input)=>{try{const url=new URL(input);return ['https:','http:'].includes(url.protocol)?url.href:null;}catch{return null;}};
export function validateRecord(kind,data){
 const errors=[];
 const title=(data.title||data.name||data.symbol||'').trim();
 if(['tasks','projects','events','opportunities','watchlist','goals','habits','automations'].includes(kind) && !title)errors.push('A name or title is required.');
 if(title.length>180)errors.push('Title is too long (maximum 180 characters).');
 if(['business','holdings','transactions'].includes(kind) && !Number.isFinite(Number(data.amount??data.quantity)))errors.push('Enter a valid number.');
 if(['business','holdings','transactions'].includes(kind) && Number(data.amount??data.quantity)<0)errors.push('Amount or quantity cannot be negative.');
 if(data.due && !/^\d{4}-\d{2}-\d{2}$/.test(data.due))errors.push('Invalid due date.');
 if(data.startsAt && !Number.isFinite(new Date(data.startsAt).getTime()))errors.push('Invalid event date.');
 if(data.startsAt&&data.endsAt&&new Date(data.endsAt)<new Date(data.startsAt))errors.push('End must be after start.');
 return errors;
}
export function investmentSummary(holdings){return holdings.reduce((acc,h)=>{const q=Number(h.quantity)||0,buy=Number(h.avgCost)||0;const current=h.currentPrice===''||h.currentPrice===null||h.currentPrice===undefined?null:Number(h.currentPrice);const c=h.currency||'EGP';acc[c]??={cost:0,value:0,priced:0,unpriced:0,gain:0};acc[c].cost+=q*buy;if(current!==null && Number.isFinite(current)){acc[c].value+=q*current;acc[c].gain+=q*(current-buy);acc[c].priced++;}else acc[c].unpriced++;return acc;},{});}
export function dueAutomations(items,now=new Date()){return items.filter(a=>a.status==='Active'&&a.nextRun&&new Date(a.nextRun).getTime()<=now.getTime());}
export function nextRunFor(frequency,from=new Date()){const d=new Date(from);if(frequency==='Hourly')d.setHours(d.getHours()+1);else if(frequency==='Weekly')d.setDate(d.getDate()+7);else d.setDate(d.getDate()+1);return d.toISOString();}
export function chatDirection(str){return /[\u0600-\u06ff]/.test(str)?'rtl':'ltr';}
export function csvSafe(s){const text=String(s??'');return /[",\n]/.test(text)?`"${text.replace(/"/g,'""')}"`:text;}
