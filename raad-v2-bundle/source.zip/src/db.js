const DB_NAME='raad-ai-local-v1';const DB_VERSION=2;
export const COLLECTIONS=['tasks','events','projects','business','opportunities','watchlist','holdings','transactions','goals','habits','checkins','automations','automationLogs','messages','notes','settings','alerts','milestones','clients'];
let database;
export function openDB(){if(database)return Promise.resolve(database);return new Promise((resolve,reject)=>{if(!('indexedDB' in globalThis))return reject(new Error('IndexedDB not supported by this browser.'));const request=indexedDB.open(DB_NAME,DB_VERSION);request.onupgradeneeded=()=>{const db=request.result;for(const name of COLLECTIONS){if(!db.objectStoreNames.contains(name))db.createObjectStore(name,{keyPath:'id'});}};request.onsuccess=()=>{database=request.result;database.onversionchange=()=>{database.close();database=null;};resolve(database);};request.onerror=()=>reject(request.error);request.onblocked=()=>reject(new Error('Database upgrade blocked. Close other RAAD tabs and refresh.'));});}
export async function all(kind){const db=await openDB();return new Promise((resolve,reject)=>{const req=db.transaction(kind,'readonly').objectStore(kind).getAll();req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});}
export async function put(kind,item){const db=await openDB();return new Promise((resolve,reject)=>{const tx=db.transaction(kind,'readwrite');tx.objectStore(kind).put(item);tx.oncomplete=()=>resolve(item);tx.onerror=()=>reject(tx.error);});}
export async function remove(kind,id){const db=await openDB();return new Promise((resolve,reject)=>{const tx=db.transaction(kind,'readwrite');tx.objectStore(kind).delete(id);tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error);});}
export async function clearAll(){const db=await openDB();const tx=db.transaction(COLLECTIONS,'readwrite');for(const name of COLLECTIONS)tx.objectStore(name).clear();return new Promise((resolve,reject)=>{tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);});}
export async function snapshot(){const result={schema:1,exportedAt:new Date().toISOString(),data:{}};for(const kind of COLLECTIONS)result.data[kind]=await all(kind);return result;}
export async function replaceSnapshot(input){
 if(input?.schema!==1||!input?.data||typeof input.data!=='object')throw new Error('Unsupported backup format.');
 // Validate *all* collections before starting a destructive transaction.
 for(const name of COLLECTIONS){const arr=input.data[name]??[];
  if(!Array.isArray(arr)||arr.length>100000)throw new Error(`Invalid backup collection: ${name}`);
  if(arr.some(entry=>!entry||typeof entry.id!=='string'||!entry.id.trim()))throw new Error(`Invalid record in backup: ${name}`);
 }
 const db=await openDB();const tx=db.transaction(COLLECTIONS,'readwrite');
 for(const name of COLLECTIONS){const store=tx.objectStore(name);store.clear();for(const entry of (input.data[name]??[]))store.put(entry);}
 return new Promise((resolve,reject)=>{tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error||new Error('Restore aborted'));});
}
